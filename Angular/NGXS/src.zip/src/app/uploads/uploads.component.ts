import { Component, OnInit } from '@angular/core';
import {FormGroup ,FormBuilder, Validators } from '@angular/forms';
import { FileUploadService } from '../Service/file-upload.service'
import { FileToUploads } from 'src/app/models/Fileupload';

const MAX_SIZE: number = 1000048576;

@Component({
  selector: 'app-uploads',
  templateUrl: './uploads.component.html',
  styleUrls: ['./uploads.component.css']
})
export class UploadsComponent implements OnInit {
  
  profileForm:FormGroup;
  error:string;
  theFile: any = null;
  theFiles: any[] = [];

  messages: string[] = [];  
  fileUpload = { status: '', message: '', filePath: '' };

  constructor(private fb:FormBuilder,private fileUploadService: FileUploadService) { }

  ngOnInit() {
    this.profileForm = this.fb.group({
      name:[''],
      content:['']
    });
  }

  onSelectedFile(event){
    this.theFiles = [];
        
    // Any file(s) selected from the input?
    if (event.target.files &&
        event.target.files.length > 0) {
      for (let index = 0;
               index < event.target.files.length;
               index++) {
        let file = event.target.files[index];
        // Don't allow file sizes over 1MB
        if (file.size < MAX_SIZE) {
          // Add file to list of files
          this.theFiles.push(file);
        }
        else {
          this.messages.push("File: " + file.name
             + " is too large to upload.");
        }
      }
    }
    if(event.target.files.length>0){
      const content= event.target.files[0];
      this.profileForm.get('content').setValue(content);
      this.profileForm.get('name').setValue(content.name);
      console.log(event.target.files);
      console.log(content.name);
      console.log(this.profileForm.get('content'));
    }
  }

  onSubmit() {
    debugger;
    const formData = new  FormData();
   formData.append('name',this.profileForm.get('name').value);
    formData.append('content',this.profileForm.get('content').value);
    for (let index = 0;index < this.theFiles.length;index++) {
            this.readAndUploadFile(this.theFiles[index]);
          }
  //   this.fileUploadService.upload(formData).subscribe(
  //     res => this.fileUpload = res,
  //     err => this.error = err,  
  // );

    console.log(this.profileForm);
    console.log(this.fileUpload);
    console.log(formData.getAll);
  }

  private readAndUploadFile(theFile: any) {
        let file = new FileToUploads();
            
        // Set File Information
        file.fileName = theFile.name;
        file.fileSize = theFile.size;
        file.fileType = theFile.type;
        file.lastModifiedTime = theFile.lastModified;
        file.lastModifiedDate = theFile.lastModifiedDate;
            
 
            
          // POST to server
          this.fileUploadService.uploadFile(file)
            .subscribe(resp =>
              { this.messages.push("Upload complete"); });
      
              console.log(file);
      }
  
 }
